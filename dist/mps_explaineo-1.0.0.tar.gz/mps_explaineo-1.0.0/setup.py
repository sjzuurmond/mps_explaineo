from setuptools import setup, find_packages

setup(
    name="mps_explaineo",
    version="1.0.0",
    description="TODO",
    author="Suzan Zuurmond",
    author_email="suzan.zuurmond.sz@gmail.com",
    packages=find_packages(),
    install_requires=[],  # List any dependencies here
)
